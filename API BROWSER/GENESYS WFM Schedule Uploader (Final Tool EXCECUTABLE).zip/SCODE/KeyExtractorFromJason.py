import json
import tkinter as tk
from tkinter import filedialog

def keyExtract():
    # 🗂️ Open file dialog
    root = tk.Tk()
    root.withdraw()
    file_path = filedialog.askopenfilename(
        title="Select a JSON file",
        filetypes=[("JSON files", "*.json")]
    )

    if file_path:
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        # 🎯 Extract all userIds
        user_ids = [agent.get("userId") for agent in data.get("agentSchedules", []) if "userId" in agent]

        # 💾 Save to a text file
        output_path = file_path.replace(".json", "_user_ids.txt")
        with open(output_path, "w", encoding="utf-8") as out_file:
            out_file.write("\n".join(user_ids))

        print(f"✅ Extracted {len(user_ids)} user IDs to: {output_path}")
    else:
        print("❌ No file selected.")
