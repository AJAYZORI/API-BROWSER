import os
import json
import math
import pandas as pd
from datetime import datetime, timedelta
from tkinter import Tk, filedialog
from pytz import timezone, utc

def msc(batch_Count):
    # Step 1: File dialog to select Excel file
    root = Tk()
    root.withdraw()
    file_path = filedialog.askopenfilename(
        title="Select Excel File",
        filetypes=[("Excel files", "*.xlsx")]
    )
    if not file_path:
        raise Exception("❌ No file selected.")

    # Step 2: Load the sheet
    sheet_name = "Schedules - India Team"
    df_raw = pd.read_excel(file_path, sheet_name=sheet_name, header=None, engine="openpyxl")

    # Step 3: Extract date row and header row
    date_row = df_raw.iloc[0]
    header_row = df_raw.iloc[1]

    # Step 4: Map valid date columns
    day_map = {}
    for idx, (date_val, day_label) in enumerate(zip(date_row, header_row)):
        try:
            parsed_date = pd.to_datetime(date_val).date()
            if day_label in ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]:
                full_day = {
                    "Mon": "Monday", "Tue": "Tuesday", "Wed": "Wednesday",
                    "Thu": "Thursday", "Fri": "Friday", "Sat": "Saturday", "Sun": "Sunday"
                }[day_label]
                day_map[full_day] = (idx, parsed_date)
        except Exception:
            continue

    if not day_map:
        raise Exception("❌ No valid date/day columns found.")

    # Step 5: Determine week start
    week_start_date = min([d for _, d in day_map.values()])

    # Step 6: Prepare data
    headers = header_row.tolist()
    data_df = df_raw.iloc[2:].copy()
    data_df.columns = headers

    # Step 7: Segments
    segments = [
        {"type": "work", "length": 60},
        {"type": "Break", "length": 15},
        {"type": "work", "length": 180},
        {"type": "Meal", "length": 30},
        {"type": "work", "length": 90},
        {"type": "Break", "length": 15},
        {"type": "work", "length": 150}
    ]
    IST = timezone("Asia/Kolkata")
    agent_schedules = []

    # Step 8: Generate agent schedules
    for _, row in data_df.iterrows():
        user_id = row.get("Genesis ID")
        if pd.isna(user_id):
            continue

        shift_time_str = str(row.get("Shift")).strip()
        if not shift_time_str or "-" not in shift_time_str:
            continue

        try:
            shift_start_str, _ = [s.strip() for s in shift_time_str.split("-")]
            shift_start_ist = datetime.strptime(shift_start_str, "%H:%M").time()
        except:
            continue

        planner = {}
        for day_name, (col_idx, _) in day_map.items():
            planner[day_name] = row.iloc[col_idx]

        shifts = []
        for day_name in ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]:
            if day_name not in planner:
                continue

            status = str(planner[day_name]).strip()
            col_idx, current_date = day_map[day_name]
            ist_datetime = IST.localize(datetime.combine(current_date, shift_start_ist))
            base_time = ist_datetime.astimezone(utc)

            if status == "WO":
                continue
            elif status == "Leave":
                shifts.append({
                    "activities": [
                        {
                            "activityCodeId": "5",
                            "startDate": base_time.isoformat().replace("+00:00", "Z"),
                            "lengthMinutes": 540,
                            "description": "",
                            "paid": False
                        }
                    ],
                    "manuallyEdited": True
                })
            elif status == "Attrition":
                continue
            else:
                activities = []
                current_time = base_time
                for seg in segments:
                    activity_code_id = (
                        "0" if seg["type"] == "work" else
                        "2" if seg["type"] == "Meal" else
                        "1"
                    )
                    activities.append({
                        "activityCodeId": activity_code_id,
                        "startDate": current_time.isoformat().replace("+00:00", "Z"),
                        "lengthMinutes": seg["length"],
                        "description": "",
                        "paid": True
                    })
                    current_time += timedelta(minutes=seg["length"])
                shifts.append({
                    "activities": activities,
                    "manuallyEdited": True
                })

        agent_schedules.append({
            "userId": user_id,
            "shifts": shifts,
            "fullDayTimeOffMarkers": [],
            "metadata": {"version": 1}
        })

    # Step 9: Output directory
    output_dir = "chunks"
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    else:
        for filename in os.listdir(output_dir):
            if filename.endswith(".json"):
                os.remove(os.path.join(output_dir, filename))

    # Step 10: Chunking and saving with updated format
    chunk_size = int(batch_Count)
    total_agents = len(agent_schedules)
    total_chunks = math.ceil(total_agents / chunk_size)

    for i in range(total_chunks):
        chunk_agents = agent_schedules[i * chunk_size:(i + 1) * chunk_size]
        chunk_json = {
            "metadata": {"version": 1},
            "agentSchedules": chunk_agents
        }
        chunk_file = os.path.join(output_dir, f"{i+1} - schedule_chunk_{week_start_date.strftime('%d_%b_%Y')}.json")
        with open(chunk_file, "w") as f:
            json.dump(chunk_json, f, indent=2)
            print(f"✅ Chunk {i+1} saved to '{chunk_file}'")

# Call the function like this:
#msc(1)  # Replace 50 with your desired chunk size
