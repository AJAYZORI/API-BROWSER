import base64
import requests
import sys
import json
import pandas as pd
from cryptography.fernet import Fernet

def RunAgentRefresh():


        # Load or generate key
    try:
        with open("secret.key", "rb") as key_file:
            key = key_file.read()
    except FileNotFoundError:
        key = Fernet.generate_key()
        with open("secret.key", "wb") as key_file:
            key_file.write(key)
    cipher = Fernet(key)

    def decrypt_data():
        try:
            with open("encrypted.txt", "rb") as f:
                lines = f.readlines()
                decrypted_ID = cipher.decrypt(lines[0].strip()).decode()
                decrypted_Secret = cipher.decrypt(lines[1].strip()).decode()
                CLIENT_ID = decrypted_ID
                CLIENT_SECRET =decrypted_Secret
                return CLIENT_ID,CLIENT_SECRET
        except Exception as e:
            print("Decryption failed!")
            return None, None

    # =================== Configuration ====================
    ENVIRONMENT = "mypurecloud.de"
    

    print("🔄 Starting Genesys Cloud Agent Refresh...")

    # === Configuration ===
    CLIENT_ID, CLIENT_SECRET = decrypt_data()    
    ENVIRONMENT = "mypurecloud.de"
    BUSINESS_UNIT_ID = "7639936a-7934-4b47-89be-9bbbdb203681"

    # === Get Access Token ===
    auth_str = f"{CLIENT_ID}:{CLIENT_SECRET}"
    auth_bytes = base64.b64encode(auth_str.encode("ISO-8859-1")).decode("ascii")
    token_headers = {
        "Authorization": f"Basic {auth_bytes}",
        "Content-Type": "application/x-www-form-urlencoded"
    }
    token_data = {"grant_type": "client_credentials"}

    token_response = requests.post(f"https://login.{ENVIRONMENT}/oauth/token", data=token_data, headers=token_headers)
    if token_response.status_code != 200:
        print(f"❌ Token request failed: {token_response.status_code} - {token_response.text}")
        sys.exit(1)

    access_token = token_response.json().get("access_token")
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json"
    }

    # === Fetch Business Units ===
    print("\n📦 Fetching Business Units...")
    bu_response = requests.get(f"https://api.{ENVIRONMENT}/api/v2/workforcemanagement/businessunits", headers=headers)
    if bu_response.status_code == 200:
        for unit in bu_response.json().get("entities", []):
            print(f"  - ID: {unit['id']}, Name: {unit['name']}")
    else:
        print(f"❌ Failed to fetch business units: {bu_response.status_code}")
        return

    # === Fetch Users with Division Info ===
    print("\n👥 Fetching Users with Division Info...")
    users_url = f"https://api.{ENVIRONMENT}/api/v2/users?q=businessUserId:{BUSINESS_UNIT_ID}&expand=division,roles,groups,permissions&pageSize=100"
    all_users = []
    page = 1

    while True:
        response = requests.get(f"{users_url}&pageNumber={page}", headers=headers)
        if response.status_code != 200:
            print(f"❌ Failed to fetch users: {response.status_code} - {response.text}")
            break

        users = response.json().get("entities", [])
        if not users:
            break

        all_users.extend(users)
        print(f"✅ Page {page}: Retrieved {len(users)} users")
        page += 1

    with open("all_users.json", "w") as f:
        json.dump(all_users, f, indent=4)
    print("📁 Saved user data to all_users.json")

    if all_users:
        df = pd.DataFrame([
            {"ID": u.get("id"), "Name": u.get("name"), "State": u.get("state")} for u in all_users
        ])
        df.to_excel("all_users.xlsx", index=False)
        print("📊 Exported user data to all_users.xlsx")


    print("\n✅ Agent refresh completed.")

#RunAgentRefresh()

