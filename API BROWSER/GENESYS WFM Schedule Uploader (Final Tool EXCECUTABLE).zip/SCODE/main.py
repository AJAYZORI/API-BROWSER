import sys
import logging
import socket
import getpass
from pathlib import Path
from datetime import datetime
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QLabel, QLineEdit, QMessageBox, QDateEdit
)
from PyQt6.QtGui import QPixmap, QColor, QTextCharFormat, QFont
from PyQt6.QtCore import QDate, QThread, pyqtSignal, QObject, QTimer
from PyQt6.uic import loadUi
import FetchAgentsSchedules, KeyExtractorFromJason, MakeScheduleInChunks, GenUploadChunkFinal

# Worker class for threading
class Worker(QObject):
    finished = pyqtSignal()
    error = pyqtSignal(str)

    def run(self):
        try:
            FetchAgentsSchedules.RunAgentRefresh()
            self.finished.emit()
        except Exception as e:
            self.error.emit(str(e))

# Logging setup
user = getpass.getuser()
hostname = socket.gethostname()
ip_address = socket.gethostbyname(hostname)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("activity_log.txt"),
        logging.StreamHandler(sys.stdout)
    ]
)

def ts():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

class MyWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        script_dir = Path(__file__).parent.resolve()
        ui_path = script_dir / "Control.ui"
        image_path = script_dir / "wns.png"

        if not ui_path.exists():
            logging.error(f"[{ts()}] {user} | UI file not found: {ui_path}")
            sys.exit(50)
        loadUi(ui_path, self)

        # Status label setup
        if hasattr(self, "label"):
            self.label.setFixedSize(100, 30)
            self.label.setStyleSheet("""
                QLabel {
                    font-size: 12px;
                    color: Blue;
                    background-color: rgba(0, 0, 0, 0);
                    padding: 4px;
                    border-radius: 4px;
                    qproperty-alignment: AlignCenter;
                }
            """)
            self.label.hide()

        # Animated dots setup
        self.loading_text = "Processing."
        self.dot_count = 0
        self.dot_timer = QTimer()
        self.dot_timer.timeout.connect(self.animate_dots)

        if hasattr(self, "lineEdit_2"):
            self.lineEdit_2.setEchoMode(QLineEdit.EchoMode.Password)

        if hasattr(self, "Logo") and isinstance(self.Logo, QLabel):
            pixmap = QPixmap(str(image_path))
            if not pixmap.isNull():
                self.Logo.setPixmap(pixmap)
                self.Logo.setScaledContents(True)
            else:
                logging.warning(f"[{ts()}] {user} | Failed to load image: {image_path}")

        if hasattr(self, "RefreshAgents"):
            self.RefreshAgents.clicked.connect(self.call_fetch_agents)
        if hasattr(self, "ExtractIDFromJson"):
            self.ExtractIDFromJson.clicked.connect(self.call_ExtractIDFromJson)
        if hasattr(self, "ctoj"):
            self.ctoj.clicked.connect(self.call_cts)
        if hasattr(self, "upl"):
            self.upl.clicked.connect(self.call_upl)
        if hasattr(self, "lineEdit"):
            self.lineEdit.setText("50")

        if hasattr(self, "dateEdit") and isinstance(self.dateEdit, QDateEdit):
            self.dateEdit.setCalendarPopup(True)
            self.dateEdit.setDate(QDate.currentDate())
            self.dateEdit.dateChanged.connect(self.handle_date_changed)
            self.setup_calendar_format()

        self.setWindowTitle("Control Panel")
        self.resize(600, 323)

    def animate_dots(self):
        self.dot_count = (self.dot_count + 1) % 4
        dots = "." * self.dot_count
        self.label.setText(f"{self.loading_text}{dots}")

    def start_text_status(self):
        self.label.setText(self.loading_text)
        self.dot_count = 0
        self.label.show()
        self.dot_timer.start(300)

    def stop_text_status(self, final_message="Done ✅"):
        self.dot_timer.stop()
        self.label.setText(final_message)
        QTimer.singleShot(1000, self.label.hide)

    def call_fetch_agents(self):
        self.thread = QThread()
        self.worker = Worker()
        self.worker.moveToThread(self.thread)

        self.start_text_status()

        self.thread.started.connect(self.worker.run)
        self.worker.finished.connect(self.thread.quit)
        self.worker.finished.connect(self.worker.deleteLater)
        self.thread.finished.connect(self.thread.deleteLater)
        self.worker.finished.connect(lambda: self.stop_text_status("Agent refresh complete"))
        self.worker.finished.connect(lambda: self.show_message("Success", "Agent schedules fetched successfully."))
        self.worker.error.connect(lambda msg: self.stop_text_status("Error occurred"))
        self.worker.error.connect(lambda msg: self.show_message("Error", msg, QMessageBox.Icon.Critical))

        logging.info(f"[{ts()}] {user} triggered: FetchAgentsSchedules.RunAgentRefresh")
        self.thread.start()

    def call_ExtractIDFromJson(self):
        try:
            self.start_text_status()
            logging.info(f"[{ts()}] {user} triggered: KeyExtractorFromJason.keyExtract")
            KeyExtractorFromJason.keyExtract()
            self.stop_text_status("ID extraction complete")
            self.show_message("Success", "ID Fetch Done From JSON.")
        except Exception as e:
            self.stop_text_status("Error occurred")
            logging.exception(f"[{ts()}] {user} | Error during ID extraction")

    def call_cts(self):
        try:
            self.start_text_status()
            batchCount = self.lineEdit.text()
            logging.info(f"[{ts()}] {user} triggered: MakeScheduleInChunks.msc({batchCount})")
            MakeScheduleInChunks.msc(batchCount)
            self.stop_text_status("Conversion complete")
            self.show_message("Success", "Excel File Converted To JSON Format For Upload.")
        except Exception as e:
            self.stop_text_status("Error occurred")
            logging.exception(f"[{ts()}] {user} | Error during chunk conversion")

    def call_upl(self):
        try:
            self.start_text_status()
            selected_date = self.dateEdit.date().toString("yyyy-MM-dd")
            logging.info(f"[{ts()}] {user} triggered: GenUploadChunkFinal.genupload({selected_date})")
            GenUploadChunkFinal.genupload(selected_date)
            self.stop_text_status("Upload complete")
            self.show_message("Success", "Schedule Batch Uploaded.")
        except Exception as e:
            self.stop_text_status("Error occurred")
            logging.exception(f"[{ts()}] {user} | Error during upload")

    def handle_date_changed(self, date):
        if date.dayOfWeek() != 1:
            logging.warning(f"[{ts()}] {user} selected invalid date: {date.toString('yyyy-MM-dd')}")
            self.show_message("Invalid Date", "Please select a Monday only.", QMessageBox.Icon.Warning)
            previous_monday = date.addDays(-((date.dayOfWeek() - 1) % 7))
            self.dateEdit.setDate(previous_monday)
        else:
            selected = date.toString("yyyy-MM-dd")
            logging.info(f"[{ts()}] {user} selected valid date: {selected}")
            self.show_message("Date Selected", f"You picked: {selected}")

    def show_message(self, title, message, icon=QMessageBox.Icon.Information):
        msg_box = QMessageBox(self)
        msg_box.setWindowTitle(title)
        msg_box.setText(message)
        msg_box.setIcon(icon)
        msg_box.setStandardButtons(QMessageBox.StandardButton.Ok)
        msg_box.exec()

    def setup_calendar_format(self):
        calendar = self.dateEdit.calendarWidget()
        calendar.setGridVisible(True)
        calendar.setStyleSheet("""
            QCalendarWidget {
                background-color: #121212;
                color: white;
                font-family: 'Segoe UI';
                font-size: 14px;
                border: none;
            }
            QCalendarWidget QWidget#qt_calendar_navigationbar {
                background-color: #1f1f1f;
                color: white;
            }
            QCalendarWidget QToolButton {
                background-color: #1f1f1f;
                color: white;
                border: none;
                font-weight: bold;
            }
            QCalendarWidget QAbstractItemView {
                background-color: #121212;
                color: white;
                selection-background-color: #1E88E5;
                selection-color: white;
                gridline-color: #333333;
            }
            QCalendarWidget QSpinBox {
                background-color: #1f1f1f;
                color: white;
                border: none;
            }
        """)

        bold_monday = QTextCharFormat()
        bold_monday.setFontWeight(QFont.Weight.Bold)
        bold_monday.setForeground(QColor("white"))
        bold_monday.setBackground(QColor("#1E88E5"))

        disabled_day = QTextCharFormat()
        disabled_day.setForeground(QColor("#555555"))
        disabled_day.setBackground(QColor("#121212"))

        min_date = calendar.minimumDate()
        max_date = calendar.maximumDate()
        d = min_date
        while d <= max_date:
            if d.dayOfWeek() == 1:
                calendar.setDateTextFormat(d, bold_monday)
            else:
                calendar.setDateTextFormat(d, disabled_day)
            d = d.addDays(1)


if __name__ == "__main__":
    logging.info(f"[{ts()}] Tool launched by: {user} on {hostname} ({ip_address})")
    app = QApplication(sys.argv)
    window = MyWindow()
    window.show()
    sys.exit(app.exec())
