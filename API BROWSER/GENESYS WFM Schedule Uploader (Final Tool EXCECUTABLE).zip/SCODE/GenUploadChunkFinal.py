from datetime import datetime
import os
import json
import gzip
import time
import requests
import re
from urllib.parse import urlencode
from cryptography.fernet import Fernet

def genupload(WEEK_ID_VAL):

        # Load or generate key
    try:
        with open("secret.key", "rb") as key_file:
            key = key_file.read()
    except FileNotFoundError:
        key = Fernet.generate_key()
        with open("secret.key", "wb") as key_file:
            key_file.write(key)
    cipher = Fernet(key)

    def decrypt_data():
        try:
            with open("encrypted.txt", "rb") as f:
                lines = f.readlines()
                decrypted_ID = cipher.decrypt(lines[0].strip()).decode()
                decrypted_Secret = cipher.decrypt(lines[1].strip()).decode()
                CLIENT_ID = decrypted_ID
                CLIENT_SECRET =decrypted_Secret
                return CLIENT_ID,CLIENT_SECRET
        except Exception as e:
            print("Decryption failed!")
            return None, None

    # =================== Configuration ====================
    ENVIRONMENT = "mypurecloud.de"
    
    CLIENT_ID, CLIENT_SECRET = decrypt_data()
    BUSINESS_UNIT_ID = "7639936a-7934-4b47-89be-9bbbdb203681"
    WEEK_ID = WEEK_ID_VAL
    CHUNKS_FOLDER = "chunks"
    date_obj = datetime.strptime(WEEK_ID_VAL, "%Y-%m-%d")
    formatted_date = date_obj.strftime("%d") + date_obj.strftime("%b'%y")
    day = int(date_obj.strftime("%d"))
    # Add ordinal suffix
    if 4 <= day <= 20 or 24 <= day <= 30:
        suffix = "th"
    else:
        suffix = ["st", "nd", "rd"][day % 10 - 1]
        # Final string
    final_date = date_obj.strftime(f"%d{suffix} %b'%y")
    print(final_date)




    # =================== Step 1: Get Access Token ====================
    def get_access_token(client_id, client_secret, environment):
        url = f"https://login.{environment}/oauth/token"
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        payload = {
            "grant_type": "client_credentials",
            "client_id": client_id,
            "client_secret": client_secret
        }
        try:
            response = requests.post(url, data=urlencode(payload), headers=headers)
            response.raise_for_status()
            return response.json()["access_token"]
        except Exception as e:
            print("❌ Failed to get access token:", e)
            return None

    access_token = get_access_token(CLIENT_ID, CLIENT_SECRET, ENVIRONMENT)
    if not access_token:
        print("❌ Cannot continue without access token.")
        return

    # =================== Step 2: Create Blank Schedule ====================
    
    create_schedule_url = (
        f"https://api.{ENVIRONMENT}/api/v2/workforcemanagement/businessunits/"
        f"{BUSINESS_UNIT_ID}/weeks/{WEEK_ID}/schedules"
    )

    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json"
    }

    blank_schedule_payload = {
        "description": f"Final Schedule WC {final_date}",  # Customize as needed
        "shortTermForecastId": None,
        "weekCount": 1,
        "metadata": {}  # optional metadata
    }

    create_response = requests.post(create_schedule_url, headers=headers, json=blank_schedule_payload)
    create_response.raise_for_status()

    # --- Retrieve Draft ID ---
    draft_id = create_response.json()["id"]
    print("✅ Blank schedule created with Draft ID:", draft_id)

    # ✅ Define the sorting key function early
    def extract_prefix_number(filename):
        match = re.match(r"^\s*(\d+)", filename)
        return int(match.group(1)) if match else 0    
    
    
    # =================== Step 3: Update Blank Schedule ====================
    SCHEDULE_ID = draft_id
    chunk_dir = "chunks"
    # Loop through all JSON files in the directory
    for filename in os.listdir(chunk_dir):
        if filename.endswith(".json"):
            file_path = os.path.join(chunk_dir, filename)
            with open(file_path, "r") as f:
                schedule_json = json.load(f)
                # Access the first agent's userId
                AGENT_ID = schedule_json["agentSchedules"][0]["userId"]
                print("✅ AGENT_ID loaded from file: ",file_path , " - ID : " , AGENT_ID)

                compressed_file_path = "schedule_update.json.gz"
                with gzip.open(compressed_file_path, "wt", encoding="utf-8") as gz_file:
                    json.dump(schedule_json, gz_file)

                file_size = os.path.getsize(compressed_file_path)

                # --- Step 3: Request Upload URL with contentLengthBytes ---
                upload_url_endpoint = (
                    f"https://api.{ENVIRONMENT}/api/v2/workforcemanagement/businessunits/"
                    f"{BUSINESS_UNIT_ID}/weeks/{WEEK_ID}/schedules/{SCHEDULE_ID}/update/uploadurl"
                )
                headers = {"Authorization": f"Bearer {access_token}"}
                upload_url_payload = {"contentLengthBytes": file_size}

                upload_url_response = requests.post(upload_url_endpoint, headers=headers, json=upload_url_payload)
                upload_url_response.raise_for_status()

                signed_url = upload_url_response.json()["url"]
                upload_key = upload_url_response.json()["uploadKey"]
                upload_headers = upload_url_response.json().get("headers", {
                    "Content-Type": "application/json",
                    "Content-Encoding": "gzip",
                    "Content-Length": str(file_size)
                })

                # --- Step 4: Upload the Compressed File ---
                with open(compressed_file_path, "rb") as f:
                    upload_response = requests.put(signed_url, headers=upload_headers, data=f)
                    upload_response.raise_for_status()

                # --- Step 5: Trigger the Schedule Update ---
                update_endpoint = (
                    f"https://api.{ENVIRONMENT}/api/v2/workforcemanagement/businessunits/"
                    f"{BUSINESS_UNIT_ID}/weeks/{WEEK_ID}/schedules/{SCHEDULE_ID}/update"
                )
                update_payload = {"uploadKey": upload_key}
                update_headers = {
                    "Authorization": f"Bearer {access_token}",
                    "Content-Type": "application/json"
                }

                update_response = requests.post(update_endpoint, headers=update_headers, json=update_payload)
                update_response.raise_for_status()

                # --- Step 6: Confirm Success ---
                print("✅ Schedule update triggered successfully!")
                os.remove("schedule_update.json.gz")
                print("🧼 Compressed file deleted successfully!")
                print(json.dumps(update_response.json(), indent=2))
                time.sleep(2)


#genupload("2025-08-04")