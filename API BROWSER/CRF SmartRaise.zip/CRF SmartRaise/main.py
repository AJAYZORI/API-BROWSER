from PyQt6.QtWidgets import QApplication, QMainWindow, QFileDialog, QLineEdit, QLabel, QMessageBox
from PyQt6.QtGui import QPixmap
from PyQt6.uic import loadUi
import sys
from pathlib import Path

class MyWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        # Get the current Python file's directory
        script_dir = Path(__file__).parent.resolve()
        ui_path = script_dir / "Control.ui"  # Ensure the UI file is located in the same folder
        image_path = script_dir / "wns.png"  # Load the logo image from the same directory

        # Load the UI file dynamically
        if not ui_path.exists():
            print(f"Error: UI file '{ui_path}' not found.")
            return
        loadUi(ui_path, self)

        # Mask the password input field
        self.lineEdit_2.setEchoMode(QLineEdit.EchoMode.Password)

        # Load the image in QLabel 'Logo'
        if hasattr(self, "Logo") and isinstance(self.Logo, QLabel):
            pixmap = QPixmap(str(image_path))  # Convert Path object to string
            
            if not pixmap.isNull():  # Ensure the image loads correctly
                self.Logo.setPixmap(pixmap)
                self.Logo.setScaledContents(True)  # Scale the image to fit QLabel
            else:
                print(f"Error: Image '{image_path}' not found or failed to load.")
        
        # Connect buttons to their respective functions
        self.toolButton_Browse.clicked.connect(self.open_file_dialog)
        self.toolButton_Run.clicked.connect(self.Run)

        self.setWindowTitle("Control Panel")
        self.resize(800, 600)

    def open_file_dialog(self):
        """Opens a file selection dialog and updates the file path in LocationPath field."""
        file_path, _ = QFileDialog.getOpenFileName(self, "Select a File", str(Path.home()), "All Files (*.*)")
    
        if file_path:  # If a file was selected, update the LocationPath field
            self.LocationPath.setText(file_path)
    
    def Run(self):
        """Captures user inputs and shows a warning message if username is missing."""
        username = self.lineEdit.text()
        password = self.lineEdit_2.text()
        filepath = self.LocationPath.text()

        if not username:  # If username is empty, show warning
            self.show_message("Blank Username", "Blank Username Not Allowed!", QMessageBox.Icon.Information)
            return
        if not password:  # If username is empty, show warning
            self.show_message("Blank Password", "Blank Password Not Allowed!", QMessageBox.Icon.Information)
            return
        if not filepath:  # If username is empty, show warning
            self.show_message("Blank Filepath", "Blank File Path Not Allowed!", QMessageBox.Icon.Critical)
            return
        
        crfCall(username,password,filepath)

    def show_message(self, title, message, icon=QMessageBox.Icon.Information):
        msg_box = QMessageBox()
        msg_box.setWindowTitle(title)
        msg_box.setText(message)
        msg_box.setIcon(icon)  # Correct icon reference
        msg_box.setStandardButtons(QMessageBox.StandardButton.Ok | QMessageBox.StandardButton.Cancel)  # Fix here

        result = msg_box.exec()  # Show message box

        if result == QMessageBox.StandardButton.Ok:  # Use StandardButton for checking response
            print("OK button clicked")
        elif result == QMessageBox.StandardButton.Cancel:
            print("Cancel button clicked")



# please add your code in crfCall function or call required function to from crf call function.
def crfCall(username,password,filepath):
    print(username + " " + password + " " + filepath)

# Run the application
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MyWindow()
    window.show()
    sys.exit(app.exec())
